# AuSum: Automatic Text Summaizer
## Tired of reading long text documents? “Let’s summarize them using Natural language techniques.”
Text summarization is one of the techniques of Natural Language Generation, having the goal to produce a concise summary while preserving key information and overall meaning.
Extractive text summarization techniques perform summarization by picking portions of texts and constructing a summary, unlike abstractive techniques which conceptualize a summary and paraphrases it.
